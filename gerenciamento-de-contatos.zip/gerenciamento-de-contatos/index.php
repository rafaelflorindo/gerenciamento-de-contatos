<?php 

	header("Location: login/");

?>