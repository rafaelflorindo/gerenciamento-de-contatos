<?php

	include_once('conexao.php');
	
	$nome 			= $_POST['nome'];
	$email 			= $_POST['email'];
	$senha 			= $_POST['senha'];
	$repetirSenha 	= $_POST['repetirSenha'];

	if ($nome=='' || $email=='' || $senha=='' || $repetirSenha=='') {
		header("Location: ../criar.conta.php?mensagem=Erro! Você precisa preencher os campos obrigatórios.");
		exit();
	}

	if ($senha==$repetirSenha) {

		$sql = mysql_query("SELECT idUsuario FROM usuarios WHERE email = '{$email}'");
		if (mysql_num_rows($sql)==0) {

			$sql = "INSERT INTO usuarios (nomeUsuario, email, senha)
					VALUES ('$nome', '$email', '$senha')";
			mysql_query($sql);

			header("Location: ../criar.conta.php?mensagem=Sucesso! Seu cadastro foi efetuado com sucesso!");
			exit();

		} else {
			header("Location: ../criar.conta.php?mensagem=Erro! Já existe um cadastro com esse e-mail.");
			exit();			
		}


	} else {

		header("Location: ../criar.conta.php?mensagem=Erro! As senhas são diferentes.");
		exit();

	}
	

?>