<?php

	//nome do banco de dados (gerenciador_contatos)
	//usuário (root)
	//senha ('')
	//server (localhost)

	$db['server'] 	= 'localhost';
	$db['user'] 	= 'root';
	$db['password'] = '';
	$db['dbname'] 	= 'gerenciador_contatos';

	$conn = mysql_connect($db['server'], $db['user'], $db['password']);
	mysql_select_db($db['dbname'], $conn);

?>