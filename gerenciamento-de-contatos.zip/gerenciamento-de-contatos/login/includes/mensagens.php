<?php
	if (isset($_GET['mensagem'])) {
		if ($_GET['tipo']=='ERRO') {
			echo "<br><div class='alert alert-danger'>".$_GET['mensagem']."</div>";
		}
		if ($_GET['tipo']=='SUCESSO') {
			echo "<br><div class='alert alert-success'>".$_GET['mensagem']."</div>";
		}
	}
?>