<?php

	include_once('conexao.php');
	session_start();
	
	$email = $_POST['email'];
	$senha = $_POST['senha'];

	if ($email=='' || $senha=='') {
		header("Location: ../index.php?tipo=ERRO&mensagem=Erro! Você precisa preencher os campos obrigatórios.");
		exit();
	}

	$sql = mysql_query("
			SELECT idUsuario, nomeUsuario, email 
			FROM usuarios 
			WHERE email = '{$email}' AND senha = '{$senha}'");

	if (mysql_num_rows($sql)==0) {

		header("Location: ../index.php?tipo=ERRO&mensagem=Erro! E-mail e/ou senha inválidos!");
		exit();	

	} else {

		$dados = mysql_fetch_assoc($sql);

		$_SESSION['idUsuario'] = $dados['idUsuario'];
		$_SESSION['nomeUsuario'] = $dados['nomeUsuario'];
		$_SESSION['email'] = $dados['email'];

		// echo "<br>ID Usuário:" . $_SESSION['idUsuario'];
		// echo "<br>Nome do Usuário: " . $_SESSION['nomeUsuario'];
		// echo "<br>E-mail: " . $_SESSION['email'];

		header("Location: ../../contatos.php");

	}

?>